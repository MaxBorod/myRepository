﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Registratsia : Form
    {
        public Registratsia()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                MessageBox.Show(("Поле Логин пустое"), "Сообщение");
            }
            else if (textBox2.Text == "")
            {
                MessageBox.Show(("Поле Пароль пустое"), "Сообщение");
            }
            //подключение к базе данных
            string connect = "data source=stud-mssql.sttec.yar.ru,38325;initial catalog=user126_db;persist security info=True;user id=user126_db;password=user126;MultipleActiveResultSets=True;App=EntityFramework";

            SqlConnection myConnection = new SqlConnection(@connect);

            myConnection.Open();//Открытие подключения

            //вывод данных из таблицы users по логину и паролю
            string command = "Select * from Пользователь_Z where Логин='" + textBox1.Text + "' and Пароль='" + textBox2.Text  + "'";
            string Роль = "0";
            string Наименование = "Заказчик";

            //Закрываем соединение  
            //myConnection.Close();

            // Добавление
            string sInsSql = "Insert into Пользователь_Z(Логин,Пароль,Роль,Наименование) Values('{0}', '{1}', '{2}', '{3}')";

            // Считываем данные с формы 
            string Surname = textBox1.Text;
            string name = textBox2.Text;
           
            // Формируем запрос на вставку данных с формы
            string sInsSotr = string.Format(sInsSql, Surname, name, Роль, Наименование);

            // Создаем команду 
            SqlCommand cmdIns = new SqlCommand(sInsSotr, myConnection);

            // Выполняем команду на вставку записи 
            cmdIns.ExecuteNonQuery();

            // Выводим сообщение ...
            MessageBox.Show(string.Format($"[Surname] {Surname} успешно добавлено"), "Сообщение");
            MessageBox.Show(string.Format($"[name] {name} успешно добавлено"), "Сообщение");
            MessageBox.Show(string.Format($"[Роль] {Роль} успешно добавлено"), "Сообщение");
            MessageBox.Show(string.Format($"[Наименование] {Наименование} успешно добавлено"), "Сообщение");
            myConnection.Close();

            Form men = new MainForm();//Переход на другую форму
            men.Show();
            this.Hide();
            MessageBox.Show("СОС не сас, всё работает заказчик");
        }
    }
}
