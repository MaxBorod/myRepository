﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
          
        }

        public void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                MessageBox.Show(("Поле Surname пустое"), "Сообщение");
            }
            else if (textBox2.Text == "")
            {
                MessageBox.Show(("Поле Password пустое"), "Сообщение");
            }
            string connect = "data source=stud-mssql.sttec.yar.ru,38325;initial catalog=user126_db;persist security info=True;user id=user126_db;password=user126;MultipleActiveResultSets=True;App=EntityFramework";
            //вывод данных
            string command = "Select * from Пользователь_Z where Логин='" + textBox1.Text + "' and Пароль='" + textBox2.Text + "'";
            SqlConnection myConnection = new SqlConnection(connect);
            SqlCommand myCommand = new SqlCommand(command, myConnection);
            myConnection.Open();
            SqlDataReader rd = myCommand.ExecuteReader();//чтение строк
            //Переменные для хранения данных, чтоб не ругался компилятор
            string Логин = "null"; //или просто ""
           
            string Пароль = "null";
            string Роль = "null";

            while (rd.Read())//Чтение данных
            {
                Логин = rd.GetString(0);

                Пароль = rd.GetString(1);
                Роль = rd.GetString(2);

            }
            myConnection.Close();
            if ((Логин == "null") || (Пароль == "null"))// если введены неправильные данные

            { MessageBox.Show("Неправильный логин или пароль"); }
            else if (Роль == "0")
            {
                MainForm men = new MainForm();//Переход на другую форму
                men.comboBox1.Text = men.comboBox1.Items[0].ToString();
                men.Show();
                 this.Hide();
                MessageBox.Show("СОС не сас, всё работает заказчик");
            }
            else if (Роль == "1")
            {

                MainForm men = new MainForm();//Переход на другую форму
                men.comboBox1.Text = men.comboBox1.Items[1].ToString();
                 men.Show();
              
               
                this.Hide();
                MessageBox.Show("САС не сос, всё работает менеджер");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           
        }
    }
}
